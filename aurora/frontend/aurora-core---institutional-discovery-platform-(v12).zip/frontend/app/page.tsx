
export default function Page() {
  return (
    <main style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <h1>Aurora Core</h1>
      <p>Subsurface Intelligence Platform — Scaffold</p>
    </main>
  );
}
